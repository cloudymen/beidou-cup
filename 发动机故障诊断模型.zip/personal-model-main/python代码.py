#!/usr/bin/env python
# coding: utf-8

# In[1]:


# 查看当前挂载的数据集目录
get_ipython().system('ls /home/aistudio/data/')


# In[2]:


# 查看个人持久化工作区文件
get_ipython().system('ls /home/aistudio/work/')


# **数据准备阶段**
# 
# 读取航空发动机模拟数据，每个发动机的第一条数据为正常状态数据，最后一条数据为故障状态数据，共有4个故障状态，分别为1，2，3，4，正常状态label为0

# In[3]:


import  os
import pandas as pd
import pickle
import numpy as np

data_path = 'data/data8150/'
def get_local_data(data):
    data_extract = data.iloc[:, 0:26]
    list = data_extract['NO'].unique()
    data_norm = pd.DataFrame()
    data_x = pd.DataFrame()

    for i in list:
        df_first = data_extract[data_extract.NO == i].iloc[0]
        df_last = data_extract[data_extract.NO == i].iloc[-1]
        data_norm = data_norm.append(df_first, ignore_index=True)
        data_x = data_x.append(df_last, ignore_index=True)
    return data_norm,data_x

def get_data(tag="labeled"):
    data_norm = pd.DataFrame()
    for root, _, files in os.walk(data_path):
        for file in files:
            if "001" in file:
                data = pd.read_csv(data_path+file, sep=' ')
                data_norm_1,data_1 = get_local_data(data)
            if "002" in file:
                data = pd.read_csv(data_path+file, sep=' ')
                data_norm_2,data_2 = get_local_data(data)
            if "003" in file:
                data = pd.read_csv(data_path+file, sep=' ')
                data_norm_3,data_3 = get_local_data(data)
            if "004" in file:
                data = pd.read_csv(data_path+file, sep=' ')
                data_norm_4,data_4 = get_local_data(data)
            if "111" in file:
                data = pd.read_csv(data_path+file, sep=' ')
                data_norm_5,data_11 = get_local_data(data)
            if "222" in file:
                data = pd.read_csv(data_path+file, sep=' ')
                data_norm_6,data_22 = get_local_data(data)
            if "333" in file:
                data = pd.read_csv(data_path+file, sep=' ')
                data_norm_7,data_33 = get_local_data(data)
            if "444" in file:
                data = pd.read_csv(data_path+file, sep=' ')
                data_norm_8,data_44 = get_local_data(data)
    data_norm = data_norm.append([data_norm_1,data_norm_2,data_norm_3,data_norm_4,data_norm_5,data_norm_6,data_norm_7,data_norm_8],ignore_index=True)
    data_1 = data_1.append(data_11,ignore_index=True)
    data_2 = data_2.append(data_22, ignore_index=True)
    data_3 = data_3.append(data_33, ignore_index=True)
    data_4 = data_4.append(data_44, ignore_index=True)
    return data_norm, data_1,data_2,data_3,data_4

def  get_numpy_data(data):
    data = data.iloc[:,1:-1]
    print(data.describe())
    print(data.head())
    return np.array(data)

class LABEL(object):
    NL = 0
    FE = 1
    FF = 2
    HE = 3
    HF = 4

def run():
    data_norm, data_1,data_2,data_3,data_4= get_data()
    normal,fault_1,  fault_2, fault_3,fault_4 = [LABEL.NL]*data_norm.shape[0],[LABEL.FE]*data_1.shape[0],                                                [LABEL.FF]*data_2.shape[0],[LABEL.HE]*data_3.shape[0],[LABEL.HF]*data_4.shape[0]
    print(len(normal))
    print(len(fault_1))
    print(len(fault_2))
    print(len(fault_4))


    labels = normal+fault_1+fault_2+fault_3+fault_4
    print(len(labels))

    data_select = data_norm.append([data_1,data_2,data_3,data_4])
    data_select_array = get_numpy_data(data_select)
    print(data_select_array.shape)
    jsj_data_file = data_path +'jsj_data.pkl'

    jsj_data = open(jsj_data_file, 'wb')
    pickle.dump(data_select_array,jsj_data)
    pickle.dump(labels, jsj_data)
    jsj_data.close()

    data_fault = pd.DataFrame()
    data_fault = data_fault.append([data_1,data_2,data_3,data_4],ignore_index=True)

    print(data_select.shape)
    print(data_fault.shape)
    print(data_1.shape)
    print(data_2.shape)
    print(data_3.shape)
    print(data_4.shape)
   #1418   709
   #1414

if __name__ == "__main__":
    run()


# **读取样本数据，将多分类问题变为两分类问题**

# In[4]:


import numpy as np

import pickle

f = open('data/data8150/jsj_data.pkl','rb')

data = pickle.load(f)

label = pickle.load(f)

f.close()


#print(data)

print(data.shape)


label = np.array(label)


label = np.array(label>0).astype(np.int)

print(label.shape)


# **数据预处理**
# 
# 1）数据正则化处理

# In[5]:


from sklearn.preprocessing import StandardScaler



normalizer = StandardScaler().fit(data)  # fit does nothing

data_scale = normalizer.transform(data)


print(data_scale.shape)

print(data_scale.mean(axis=0))

print(data_scale.std(axis=0))


# **数据预处理**
# 
# 2）主成分分析降维

# In[6]:


from sklearn.decomposition import PCA



pca = PCA(n_components=21)

newX = pca.fit_transform(data_scale)

print (pca.explained_variance_ratio_)

print(np.sum(np.array(pca.explained_variance_ratio_)))


# **SVM模型**
# 
# 1)创建SVM模型对象
# 
# 2)SVM模型训练

# In[7]:


from sklearn.model_selection import train_test_split

from sklearn.ensemble import RandomForestClassifier

from sklearn.svm import SVC


trainX, testX, trainY, testY = train_test_split(newX, label, test_size=0.1, random_state=42)

print(trainX.shape)

print(trainY.shape)


#clf = RandomForestClassifier()

clf = SVC(probability=True)

clf.fit(trainX,trainY)


# In[8]:


from sklearn.metrics import accuracy_score

from sklearn.metrics import confusion_matrix

from sklearn.metrics import classification_report


predict_results=clf.predict(testX)

print(accuracy_score(predict_results, testY))

conf_mat = confusion_matrix(testY, predict_results)

print(conf_mat)

print(classification_report(testY, predict_results))


# **绘制ROC曲线**

# In[9]:


get_ipython().run_line_magic('matplotlib', 'inline')
from sklearn.metrics import roc_curve, auc

import matplotlib.pyplot as plt


#print(testX.shape)

predict_prob=clf.predict_proba(testX)


#print(predict_prob.shape)

index = np.argsort(testY)

testY = np.sort(testY)

predict_prob = predict_prob[index,:]



#print(predict_prob[:,1])


false_positive_rate, true_positive_rate, thresholds = roc_curve(testY,predict_prob[:,1])


#print(false_positive_rate)

#print(true_positive_rate)

#print(thresholds)

roc_auc=auc(false_positive_rate, true_positive_rate)


plt.figure()

plt.plot(false_positive_rate, true_positive_rate,'b',label='AUC = %0.2f'% roc_auc)

plt.legend(loc='lower right')

plt.plot([0,1],[0,1],'r--')

plt.xlabel('False Positive Rate')

plt.ylabel('True Positive Rate')

plt.title('receiver operating characteristic')

plt.xlim([0.0, 1.0])

plt.ylim([0.0, 1.0])

plt.legend(loc="lower right")

plt.show()


# **保存模型**

# In[10]:


from sklearn.externals import joblib

model_path = 'work/'

joblib_file = "joblib_model.pkl"  

joblib.dump(clf, model_path+joblib_file)


# In[ ]:




